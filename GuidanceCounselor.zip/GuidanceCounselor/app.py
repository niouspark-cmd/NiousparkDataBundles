import os
import logging
from flask import Flask

# Configure logging for debugging
logging.basicConfig(level=logging.DEBUG)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "counseling-management-secret-key-2025")

# Database configuration - using SQLite for offline operation
DATABASE_PATH = 'counseling.db'
app.config['DATABASE'] = DATABASE_PATH

# Import and register routes
from routes import *
from database import init_db

# Initialize database
with app.app_context():
    init_db()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
