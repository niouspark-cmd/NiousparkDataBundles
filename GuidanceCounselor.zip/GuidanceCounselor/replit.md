# replit.md

## Overview

This is a **Counseling Management System** designed for the AAMUSTED Guidance & Counselling Centre. It's a Flask-based web application that manages student counseling activities including intake, appointments, sessions, case management, referrals, and assessments. The system is built to be completely offline and self-contained, using SQLite as the database to ensure it can run without any external dependencies or internet connection.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Framework
- **Flask**: Chosen as the web framework for its simplicity and lightweight nature
- **Python 3.x**: Programming language for server-side logic
- **SQLite**: Database management system selected for offline operation and portability
- **No authentication system**: Single-user application designed for counselor-only access

### Frontend Architecture
- **Bootstrap 5**: CSS framework for responsive design with dark theme
- **Jinja2 Templates**: Server-side templating engine integrated with Flask
- **Font Awesome**: Icon library for UI elements
- **Chart.js**: JavaScript library for data visualization in reports
- **Vanilla JavaScript**: For client-side interactions and filtering

### Application Structure
- **MVC Pattern**: Separation of concerns with models, views (templates), and controllers (routes)
- **Modular Design**: Separate files for database operations, models, and routes
- **Template Inheritance**: Base template with consistent navigation and styling

## Key Components

### Core Entities
1. **Students**: Student registration and profile management
2. **Counselors**: Counselor information and assignment
3. **Appointments**: Scheduling system for counseling sessions
4. **Sessions**: Recording of actual counseling sessions and notes
5. **Case Management**: Detailed case notes with interventions and recommendations
6. **Referrals**: External referral tracking system
7. **Assessments**: DASS-21 and Outcome Questionnaire (OQ-45.2) tools

### Database Schema
- **SQLite database** with foreign key relationships
- **Timestamp tracking** for all records
- **Flexible session types**: Individual, Group, Crisis, Assessment, Follow-up, Consultation, Referral
- **Assessment scoring systems** for standardized psychological tools

### Report Generation
- **PDF Export**: Using ReportLab for professional documents
- **Word Documents**: Using python-docx for editable reports
- **CSV Export**: For data backup and analysis
- **Print-friendly pages**: Dedicated printing templates

## Data Flow

### Student Workflow
1. **Intake Process**: New student registration with complete information
2. **Appointment Booking**: Scheduling with available counselors
3. **Session Logging**: Recording session details and notes
4. **Case Management**: Detailed tracking of interventions and progress
5. **Assessment Administration**: DASS-21 and outcome questionnaires
6. **Referral Process**: External referrals when needed

### Data Relationships
- Students can have multiple appointments and sessions
- Sessions can be linked to appointments or be walk-in sessions
- Case management notes are tied to specific sessions
- Assessments are linked to students and optionally to sessions
- Referrals originate from specific sessions

## External Dependencies

### Python Libraries
- **Flask**: Web framework
- **SQLite3**: Database connectivity (built into Python)
- **ReportLab**: PDF generation
- **python-docx**: Word document creation
- **CSV module**: Data export functionality (built into Python)

### Frontend Libraries (CDN)
- **Bootstrap 5**: CSS framework with dark theme
- **Font Awesome 6**: Icon library
- **Chart.js**: Data visualization

### No External Services
- No cloud databases or authentication services
- No external APIs or web services
- Completely offline operation capability

## Deployment Strategy

### Development Environment
- **Replit**: Used for development and testing
- **Debug mode enabled**: For development convenience
- **Host configuration**: 0.0.0.0:5000 for accessibility

### Production Deployment
- **Standalone executable**: Designed to be converted to .EXE for Windows
- **Portable database**: SQLite file can be backed up and moved
- **No server requirements**: Self-contained Flask application
- **Local network access**: Can be accessed by multiple users on same network

### Data Management
- **Automatic database initialization**: Creates tables on first run
- **Bulk import/export**: CSV-based data transfer capabilities
- **Backup functionality**: Complete data export for backup purposes
- **Print capabilities**: Professional report generation for official use

The application prioritizes simplicity, offline functionality, and professional counseling workflow management while maintaining data integrity and providing comprehensive reporting capabilities.

## Recent Changes: Latest modifications with dates

### July 25, 2025 - Complete Offline Database Setup
- ✅ **SQLite3 Database**: Full offline operation with `counseling.db` file
- ✅ **Complete CSV Templates**: All 8 import/export templates created
  - Students, Counselors, Appointments, Sessions
  - Case Management, Referrals, OQ-45.2, DASS-21 assessments
- ✅ **Portable System**: Zero external dependencies for local deployment
- ✅ **Auto-initialization**: Database tables and default data created automatically
- ✅ **Comprehensive Documentation**: `OFFLINE_SETUP.md` with deployment guide
- ✅ **Ready for Export**: All features work offline without Replit dependencies