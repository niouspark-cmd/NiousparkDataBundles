import sqlite3
import os
from datetime import datetime
from flask import current_app, g

def get_db():
    """Get database connection"""
    if 'db' not in g:
        g.db = sqlite3.connect(current_app.config['DATABASE'])
        g.db.row_factory = sqlite3.Row
    return g.db

def close_db(error):
    """Close database connection"""
    db = g.pop('db', None)
    if db is not None:
        db.close()

def init_db():
    """Initialize database with all required tables"""
    db = get_db()
    
    # Create all tables
    db.executescript('''
        -- Students table
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            age INTEGER,
            gender TEXT,
            program TEXT,
            contact TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Counselors table
        CREATE TABLE IF NOT EXISTS counselors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            contact TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Appointments table
        CREATE TABLE IF NOT EXISTS appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            counselor_id INTEGER NOT NULL,
            date DATE NOT NULL,
            time TIME NOT NULL,
            purpose TEXT,
            status TEXT DEFAULT 'scheduled',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (student_id) REFERENCES students (id),
            FOREIGN KEY (counselor_id) REFERENCES counselors (id)
        );

        -- Sessions table
        CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            appointment_id INTEGER,
            counselor_id INTEGER NOT NULL,
            session_type TEXT,
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (appointment_id) REFERENCES appointments (id),
            FOREIGN KEY (counselor_id) REFERENCES counselors (id)
        );

        -- Case Management table
        CREATE TABLE IF NOT EXISTS case_management (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER NOT NULL,
            appearance TEXT,
            problems TEXT,
            interventions TEXT,
            recommendations TEXT,
            next_visit DATE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (session_id) REFERENCES sessions (id)
        );

        -- Referrals table
        CREATE TABLE IF NOT EXISTS referrals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER NOT NULL,
            referrer_name TEXT NOT NULL,
            referrer_contact TEXT,
            reasons TEXT,
            date DATE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (session_id) REFERENCES sessions (id)
        );

        -- Outcome Questionnaires table
        CREATE TABLE IF NOT EXISTS outcome_questionnaires (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            session_id INTEGER,
            total_score INTEGER NOT NULL,
            completion_date DATE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (student_id) REFERENCES students (id),
            FOREIGN KEY (session_id) REFERENCES sessions (id)
        );

        -- DASS-21 table
        CREATE TABLE IF NOT EXISTS dass21 (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            depression_score INTEGER NOT NULL,
            anxiety_score INTEGER NOT NULL,
            stress_score INTEGER NOT NULL,
            date DATE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (student_id) REFERENCES students (id)
        );

        -- Issues table (predefined list)
        CREATE TABLE IF NOT EXISTS issues (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            description TEXT
        );

        -- Session Issues junction table
        CREATE TABLE IF NOT EXISTS session_issues (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER NOT NULL,
            issue_id INTEGER NOT NULL,
            FOREIGN KEY (session_id) REFERENCES sessions (id),
            FOREIGN KEY (issue_id) REFERENCES issues (id)
        );

        -- Feedback table
        CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER NOT NULL,
            rating INTEGER CHECK (rating >= 1 AND rating <= 5),
            comments TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (session_id) REFERENCES sessions (id)
        );
    ''')
    
    # Insert default counselor if none exists
    counselor_count = db.execute('SELECT COUNT(*) FROM counselors').fetchone()[0]
    if counselor_count == 0:
        db.execute('INSERT INTO counselors (name, contact) VALUES (?, ?)', 
                  ('Default Counselor', 'counselor@aamusted.edu.gh'))
    
    # Insert predefined issues if none exist
    issue_count = db.execute('SELECT COUNT(*) FROM issues').fetchone()[0]
    if issue_count == 0:
        default_issues = [
            ('Academic Stress', 'Issues related to academic performance and pressure'),
            ('Anxiety', 'General anxiety and panic-related concerns'),
            ('Depression', 'Depressive symptoms and mood disorders'),
            ('Relationship Issues', 'Problems with interpersonal relationships'),
            ('Family Problems', 'Family-related conflicts and issues'),
            ('Financial Stress', 'Money-related concerns and financial difficulties'),
            ('Career Guidance', 'Career planning and vocational guidance'),
            ('Social Adjustment', 'Difficulties with social integration'),
            ('Substance Abuse', 'Drug and alcohol-related issues'),
            ('Grief and Loss', 'Bereavement and loss-related counseling'),
            ('Trauma', 'Post-traumatic stress and trauma recovery'),
            ('Self-Esteem', 'Self-worth and confidence issues')
        ]
        
        for issue_name, description in default_issues:
            db.execute('INSERT INTO issues (name, description) VALUES (?, ?)', 
                      (issue_name, description))
    
    db.commit()

# Database helper functions
def execute_query(query, params=None):
    """Execute a query and return results"""
    db = get_db()
    if params:
        cursor = db.execute(query, params)
    else:
        cursor = db.execute(query)
    return cursor.fetchall()

def execute_insert(query, params):
    """Execute an insert query and return the last row id"""
    db = get_db()
    cursor = db.execute(query, params)
    db.commit()
    return cursor.lastrowid

def execute_update(query, params):
    """Execute an update or delete query"""
    db = get_db()
    cursor = db.execute(query, params)
    db.commit()
    return cursor.rowcount
