"""
Database models for the Counseling Management System
All models correspond to the database tables defined in the requirements
"""

from datetime import datetime

class Student:
    def __init__(self, id=None, name=None, age=None, gender=None, program=None, contact=None, created_at=None):
        self.id = id
        self.name = name
        self.age = age
        self.gender = gender
        self.program = program
        self.contact = contact
        self.created_at = created_at or datetime.now()

class Counselor:
    def __init__(self, id=None, name=None, contact=None, created_at=None):
        self.id = id
        self.name = name
        self.contact = contact
        self.created_at = created_at or datetime.now()

class Appointment:
    def __init__(self, id=None, student_id=None, counselor_id=None, date=None, time=None, purpose=None, status='scheduled', created_at=None):
        self.id = id
        self.student_id = student_id
        self.counselor_id = counselor_id
        self.date = date
        self.time = time
        self.purpose = purpose
        self.status = status
        self.created_at = created_at or datetime.now()

class Session:
    def __init__(self, id=None, appointment_id=None, counselor_id=None, session_type=None, notes=None, created_at=None):
        self.id = id
        self.appointment_id = appointment_id
        self.counselor_id = counselor_id
        self.session_type = session_type
        self.notes = notes
        self.created_at = created_at or datetime.now()

class CaseManagement:
    def __init__(self, id=None, session_id=None, appearance=None, problems=None, interventions=None, recommendations=None, next_visit=None, created_at=None):
        self.id = id
        self.session_id = session_id
        self.appearance = appearance
        self.problems = problems
        self.interventions = interventions
        self.recommendations = recommendations
        self.next_visit = next_visit
        self.created_at = created_at or datetime.now()

class Referral:
    def __init__(self, id=None, session_id=None, referrer_name=None, referrer_contact=None, reasons=None, date=None, created_at=None):
        self.id = id
        self.session_id = session_id
        self.referrer_name = referrer_name
        self.referrer_contact = referrer_contact
        self.reasons = reasons
        self.date = date
        self.created_at = created_at or datetime.now()

class OutcomeQuestionnaire:
    def __init__(self, id=None, student_id=None, session_id=None, total_score=None, completion_date=None, created_at=None):
        self.id = id
        self.student_id = student_id
        self.session_id = session_id
        self.total_score = total_score
        self.completion_date = completion_date
        self.created_at = created_at or datetime.now()

class DASS21:
    def __init__(self, id=None, student_id=None, depression_score=None, anxiety_score=None, stress_score=None, date=None, created_at=None):
        self.id = id
        self.student_id = student_id
        self.depression_score = depression_score
        self.anxiety_score = anxiety_score
        self.stress_score = stress_score
        self.date = date
        self.created_at = created_at or datetime.now()

class Issue:
    def __init__(self, id=None, name=None, description=None):
        self.id = id
        self.name = name
        self.description = description

class SessionIssue:
    def __init__(self, id=None, session_id=None, issue_id=None):
        self.id = id
        self.session_id = session_id
        self.issue_id = issue_id

class Feedback:
    def __init__(self, id=None, session_id=None, rating=None, comments=None, created_at=None):
        self.id = id
        self.session_id = session_id
        self.rating = rating
        self.comments = comments
        self.created_at = created_at or datetime.now()
