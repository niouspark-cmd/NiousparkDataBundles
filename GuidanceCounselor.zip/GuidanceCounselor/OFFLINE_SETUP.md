# AAMUSTED Counseling Management System - Offline Setup Guide

## Database Architecture

This system uses **SQLite3** database (`counseling.db`) which is perfect for offline operation:

### ✅ Offline Features
- **No internet required** - SQLite3 is file-based and embedded
- **Portable database** - Just copy the `counseling.db` file
- **Zero configuration** - Works out of the box
- **Cross-platform** - Runs on Windows, Mac, Linux

### Database File Location
```
counseling.db - Main database file (auto-created on first run)
```

## Required Python Packages

Install these packages for local operation:
```bash
pip install Flask==3.0.0
pip install reportlab==4.0.7
pip install python-docx==1.1.0
pip install openpyxl==3.1.2
```

## Running Locally

1. **Copy all project files** to your local machine
2. **Install Python packages** (see above)
3. **Run the application**:
   ```bash
   python main.py
   ```
4. **Access via browser**: http://localhost:5000

## Data Export/Import Features

### CSV Templates Available
- `static/sample_templates/students_template.csv`
- `static/sample_templates/appointments_template.csv`
- `static/sample_templates/sessions_template.csv`
- `static/sample_templates/counselors_template.csv`
- `static/sample_templates/referrals_template.csv`

### Export Options
- **CSV Export**: All data can be exported to CSV files
- **PDF Reports**: Professional reports using ReportLab
- **Word Documents**: Editable reports using python-docx
- **Database Backup**: Simply copy the `counseling.db` file

## Database Tables Created Automatically

1. **students** - Student registration and profiles
2. **counselors** - Counselor information
3. **appointments** - Scheduled appointments
4. **sessions** - Session notes and records
5. **case_management** - Detailed case notes with interventions
6. **referrals** - External referral tracking
7. **outcome_questionnaires** - OQ-45.2 assessment scores
8. **dass21** - DASS-21 assessment results
9. **issues** - Predefined counseling issues
10. **session_issues** - Link between sessions and issues
11. **feedback** - Session feedback and ratings

## Key Benefits for Offline Use

1. **Self-contained**: No external services or cloud dependencies
2. **Portable**: Move the entire system by copying files
3. **Reliable**: SQLite3 is one of the most reliable database engines
4. **Fast**: Local database means instant response times
5. **Secure**: Data stays on your local machine
6. **Backup-friendly**: Simple file copying for backups

## File Structure for Local Deployment
```
counseling-system/
├── main.py              # Application entry point
├── app.py               # Flask application setup
├── database.py          # Database operations
├── routes.py            # All application routes
├── models.py            # Data models (if needed)
├── counseling.db        # SQLite database (auto-created)
├── static/              # CSS, JS, images
├── templates/           # HTML templates
└── sample_templates/    # CSV import templates
```

## Converting to Executable (Optional)

You can convert this to a standalone .exe file using PyInstaller:

```bash
pip install pyinstaller
pyinstaller --onefile --add-data "templates;templates" --add-data "static;static" main.py
```

This creates a single executable file that includes Python and all dependencies.