import csv
import io
import os
import zipfile
from datetime import datetime, date
from flask import render_template, request, redirect, url_for, flash, send_file, make_response
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from docx import Document
from docx.shared import Inches

from app import app
from database import get_db, execute_query, execute_insert, execute_update

@app.teardown_appcontext
def close_db(error):
    """Close database connection after each request"""
    from database import close_db
    close_db(error)

@app.route('/')
def dashboard():
    """Dashboard with live statistics"""
    try:
        # Get live statistics from database
        total_students = execute_query('SELECT COUNT(*) as count FROM students')[0]['count']
        total_appointments = execute_query('SELECT COUNT(*) as count FROM appointments')[0]['count']
        total_sessions = execute_query('SELECT COUNT(*) as count FROM sessions')[0]['count']
        total_referrals = execute_query('SELECT COUNT(*) as count FROM referrals')[0]['count']
        
        # Upcoming appointments (next 7 days)
        upcoming_appointments = execute_query('''
            SELECT a.*, s.name as student_name, c.name as counselor_name 
            FROM appointments a
            JOIN students s ON a.student_id = s.id
            JOIN counselors c ON a.counselor_id = c.id
            WHERE a.date >= date('now') AND a.date <= date('now', '+7 days')
            ORDER BY a.date ASC, a.time ASC
            LIMIT 5
        ''')
        
        # Recent sessions (last 5)
        recent_sessions = execute_query('''
            SELECT s.*, st.name as student_name, c.name as counselor_name,
                   a.date as appointment_date
            FROM sessions s
            LEFT JOIN appointments a ON s.appointment_id = a.id
            LEFT JOIN students st ON a.student_id = st.id
            JOIN counselors c ON s.counselor_id = c.id
            ORDER BY s.created_at DESC
            LIMIT 5
        ''')
        
        # Recent referrals (last 5)
        recent_referrals = execute_query('''
            SELECT r.*, st.name as student_name
            FROM referrals r
            JOIN sessions s ON r.session_id = s.id
            LEFT JOIN appointments a ON s.appointment_id = a.id
            LEFT JOIN students st ON a.student_id = st.id
            ORDER BY r.created_at DESC
            LIMIT 5
        ''')
        
        return render_template('dashboard.html',
                             total_students=total_students,
                             total_appointments=total_appointments,
                             total_sessions=total_sessions,
                             total_referrals=total_referrals,
                             upcoming_appointments=upcoming_appointments,
                             recent_sessions=recent_sessions,
                             recent_referrals=recent_referrals)
    except Exception as e:
        flash(f'Error loading dashboard: {str(e)}', 'error')
        return render_template('dashboard.html',
                             total_students=0, total_appointments=0,
                             total_sessions=0, total_referrals=0,
                             upcoming_appointments=[], recent_sessions=[],
                             recent_referrals=[])

@app.route('/students')
def students_list():
    """List all students with edit/delete options"""
    students = execute_query('SELECT * FROM students ORDER BY name ASC')
    return render_template('students_list.html', students=students)

@app.route('/add_student', methods=['GET', 'POST'])
def add_student():
    """Add new student form"""
    if request.method == 'POST':
        name = request.form['name']
        age = request.form.get('age', type=int)
        gender = request.form['gender']
        program = request.form['program']
        contact = request.form['contact']
        
        try:
            student_id = execute_insert(
                'INSERT INTO students (name, age, gender, program, contact) VALUES (?, ?, ?, ?, ?)',
                (name, age, gender, program, contact)
            )
            flash(f'Student "{name}" added successfully!', 'success')
            return redirect(url_for('students_list'))
        except Exception as e:
            flash(f'Error adding student: {str(e)}', 'error')
    
    return render_template('add_student.html')

@app.route('/edit_student/<int:student_id>', methods=['GET', 'POST'])
def edit_student(student_id):
    """Edit existing student"""
    if request.method == 'POST':
        name = request.form['name']
        age = request.form.get('age', type=int)
        gender = request.form['gender']
        program = request.form['program']
        contact = request.form['contact']
        
        try:
            execute_update(
                'UPDATE students SET name=?, age=?, gender=?, program=?, contact=? WHERE id=?',
                (name, age, gender, program, contact, student_id)
            )
            flash('Student updated successfully!', 'success')
            return redirect(url_for('students_list'))
        except Exception as e:
            flash(f'Error updating student: {str(e)}', 'error')
    
    student = execute_query('SELECT * FROM students WHERE id = ?', (student_id,))
    if not student:
        flash('Student not found', 'error')
        return redirect(url_for('students_list'))
    
    return render_template('add_student.html', student=student[0], edit_mode=True)

@app.route('/delete_student/<int:student_id>', methods=['POST'])
def delete_student(student_id):
    """Delete student and related records"""
    try:
        execute_update('DELETE FROM students WHERE id = ?', (student_id,))
        flash('Student deleted successfully!', 'success')
    except Exception as e:
        flash(f'Error deleting student: {str(e)}', 'error')
    
    return redirect(url_for('students_list'))

@app.route('/intake', methods=['GET', 'POST'])
def intake():
    """Student intake form - creates student and first appointment"""
    if request.method == 'POST':
        # Student information
        name = request.form['name']
        age = request.form.get('age', type=int)
        gender = request.form['gender']
        program = request.form['program']
        contact = request.form['contact']
        
        # Appointment information
        counselor_id = request.form.get('counselor_id', type=int)
        appointment_date = request.form['date']
        appointment_time = request.form['time']
        purpose = request.form['purpose']
        
        try:
            # Create student first
            student_id = execute_insert(
                'INSERT INTO students (name, age, gender, program, contact) VALUES (?, ?, ?, ?, ?)',
                (name, age, gender, program, contact)
            )
            
            # Create appointment
            appointment_id = execute_insert(
                'INSERT INTO appointments (student_id, counselor_id, date, time, purpose) VALUES (?, ?, ?, ?, ?)',
                (student_id, counselor_id, appointment_date, appointment_time, purpose)
            )
            
            flash(f'Student "{name}" added and appointment scheduled successfully!', 'success')
            return redirect(url_for('dashboard'))
        except Exception as e:
            flash(f'Error during intake: {str(e)}', 'error')
    
    # Get counselors for dropdown
    counselors = execute_query('SELECT * FROM counselors ORDER BY name ASC')
    return render_template('intake.html', counselors=counselors)

@app.route('/appointments')
def appointments_list():
    """List all appointments"""
    appointments = execute_query('''
        SELECT a.*, s.name as student_name, c.name as counselor_name
        FROM appointments a
        JOIN students s ON a.student_id = s.id
        JOIN counselors c ON a.counselor_id = c.id
        ORDER BY a.date DESC, a.time DESC
    ''')
    return render_template('appointments_list.html', appointments=appointments)

@app.route('/appointment', methods=['GET', 'POST'])
def appointment():
    """Book new appointment"""
    if request.method == 'POST':
        student_id = request.form.get('student_id', type=int)
        counselor_id = request.form.get('counselor_id', type=int)
        appointment_date = request.form['date']
        appointment_time = request.form['time']
        purpose = request.form['purpose']
        
        try:
            appointment_id = execute_insert(
                'INSERT INTO appointments (student_id, counselor_id, date, time, purpose) VALUES (?, ?, ?, ?, ?)',
                (student_id, counselor_id, appointment_date, appointment_time, purpose)
            )
            flash('Appointment scheduled successfully!', 'success')
            return redirect(url_for('appointments_list'))
        except Exception as e:
            flash(f'Error scheduling appointment: {str(e)}', 'error')
    
    # Get students and counselors for dropdowns
    students = execute_query('SELECT * FROM students ORDER BY name ASC')
    counselors = execute_query('SELECT * FROM counselors ORDER BY name ASC')
    return render_template('appointment.html', students=students, counselors=counselors)

@app.route('/sessions')
def sessions_list():
    """List all sessions"""
    sessions = execute_query('''
        SELECT s.*, st.name as student_name, c.name as counselor_name,
               a.date as appointment_date, a.time as appointment_time
        FROM sessions s
        LEFT JOIN appointments a ON s.appointment_id = a.id
        LEFT JOIN students st ON a.student_id = st.id
        JOIN counselors c ON s.counselor_id = c.id
        ORDER BY s.created_at DESC
    ''')
    return render_template('sessions_list.html', sessions=sessions)

@app.route('/session', methods=['GET', 'POST'])
def session():
    """Log session details"""
    if request.method == 'POST':
        appointment_id = request.form.get('appointment_id', type=int) or None
        counselor_id = request.form.get('counselor_id', type=int)
        session_type = request.form['session_type']
        notes = request.form['notes']
        
        try:
            session_id = execute_insert(
                'INSERT INTO sessions (appointment_id, counselor_id, session_type, notes) VALUES (?, ?, ?, ?)',
                (appointment_id, counselor_id, session_type, notes)
            )
            flash('Session logged successfully!', 'success')
            return redirect(url_for('sessions_list'))
        except Exception as e:
            flash(f'Error logging session: {str(e)}', 'error')
    
    # Get appointments and counselors for dropdowns
    appointments = execute_query('''
        SELECT a.*, s.name as student_name
        FROM appointments a
        JOIN students s ON a.student_id = s.id
        WHERE a.status = 'scheduled'
        ORDER BY a.date ASC, a.time ASC
    ''')
    counselors = execute_query('SELECT * FROM counselors ORDER BY name ASC')
    return render_template('session.html', appointments=appointments, counselors=counselors)

@app.route('/case_note', methods=['GET', 'POST'])
def case_note():
    """Create case management note"""
    if request.method == 'POST':
        session_id = request.form.get('session_id', type=int)
        appearance = request.form['appearance']
        problems = request.form['problems']
        interventions = request.form['interventions']
        recommendations = request.form['recommendations']
        next_visit = request.form.get('next_visit') or None
        
        try:
            case_id = execute_insert(
                'INSERT INTO case_management (session_id, appearance, problems, interventions, recommendations, next_visit) VALUES (?, ?, ?, ?, ?, ?)',
                (session_id, appearance, problems, interventions, recommendations, next_visit)
            )
            flash('Case note created successfully!', 'success')
            return redirect(url_for('dashboard'))
        except Exception as e:
            flash(f'Error creating case note: {str(e)}', 'error')
    
    # Get sessions for dropdown
    sessions = execute_query('''
        SELECT s.*, st.name as student_name, c.name as counselor_name
        FROM sessions s
        LEFT JOIN appointments a ON s.appointment_id = a.id
        LEFT JOIN students st ON a.student_id = st.id
        JOIN counselors c ON s.counselor_id = c.id
        ORDER BY s.created_at DESC
    ''')
    return render_template('case_note.html', sessions=sessions)

@app.route('/referral', methods=['GET', 'POST'])
def referral():
    """Create referral"""
    if request.method == 'POST':
        session_id = request.form.get('session_id', type=int)
        referrer_name = request.form['referrer_name']
        referrer_contact = request.form['referrer_contact']
        reasons = request.form['reasons']
        referral_date = request.form['date']
        
        try:
            referral_id = execute_insert(
                'INSERT INTO referrals (session_id, referrer_name, referrer_contact, reasons, date) VALUES (?, ?, ?, ?, ?)',
                (session_id, referrer_name, referrer_contact, reasons, referral_date)
            )
            flash('Referral created successfully!', 'success')
            return redirect(url_for('dashboard'))
        except Exception as e:
            flash(f'Error creating referral: {str(e)}', 'error')
    
    # Get sessions for dropdown
    sessions = execute_query('''
        SELECT s.*, st.name as student_name, c.name as counselor_name
        FROM sessions s
        LEFT JOIN appointments a ON s.appointment_id = a.id
        LEFT JOIN students st ON a.student_id = st.id
        JOIN counselors c ON s.counselor_id = c.id
        ORDER BY s.created_at DESC
    ''')
    return render_template('referral.html', sessions=sessions)

@app.route('/oq', methods=['GET', 'POST'])
def outcome_questionnaire():
    """Outcome Questionnaire (OQ-45.2) entry"""
    if request.method == 'POST':
        student_id = request.form.get('student_id', type=int)
        session_id = request.form.get('session_id', type=int) or None
        total_score = request.form.get('total_score', type=int)
        completion_date = request.form['completion_date']
        
        try:
            oq_id = execute_insert(
                'INSERT INTO outcome_questionnaires (student_id, session_id, total_score, completion_date) VALUES (?, ?, ?, ?)',
                (student_id, session_id, total_score, completion_date)
            )
            flash('Outcome Questionnaire recorded successfully!', 'success')
            return redirect(url_for('dashboard'))
        except Exception as e:
            flash(f'Error recording outcome questionnaire: {str(e)}', 'error')
    
    # Get students and sessions for dropdowns
    students = execute_query('SELECT * FROM students ORDER BY name ASC')
    sessions = execute_query('''
        SELECT s.*, st.name as student_name
        FROM sessions s
        LEFT JOIN appointments a ON s.appointment_id = a.id
        LEFT JOIN students st ON a.student_id = st.id
        ORDER BY s.created_at DESC
    ''')
    return render_template('outcome_questionnaire.html', students=students, sessions=sessions)

@app.route('/dass21', methods=['GET', 'POST'])
def dass21():
    """DASS-21 assessment entry"""
    if request.method == 'POST':
        student_id = request.form.get('student_id', type=int)
        depression_score = request.form.get('depression_score', type=int)
        anxiety_score = request.form.get('anxiety_score', type=int)
        stress_score = request.form.get('stress_score', type=int)
        assessment_date = request.form['date']
        
        try:
            dass_id = execute_insert(
                'INSERT INTO dass21 (student_id, depression_score, anxiety_score, stress_score, date) VALUES (?, ?, ?, ?, ?)',
                (student_id, depression_score, anxiety_score, stress_score, assessment_date)
            )
            flash('DASS-21 assessment recorded successfully!', 'success')
            return redirect(url_for('dashboard'))
        except Exception as e:
            flash(f'Error recording DASS-21 assessment: {str(e)}', 'error')
    
    # Get students for dropdown
    students = execute_query('SELECT * FROM students ORDER BY name ASC')
    return render_template('dass21.html', students=students)

@app.route('/import', methods=['GET', 'POST'])
def bulk_import():
    """Bulk CSV import functionality"""
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file selected', 'error')
            return redirect(request.url)
        
        file = request.files['file']
        import_type = request.form['import_type']
        
        if file.filename == '':
            flash('No file selected', 'error')
            return redirect(request.url)
        
        if file and file.filename.endswith('.csv'):
            try:
                # Read CSV file
                stream = io.StringIO(file.stream.read().decode("UTF8"), newline=None)
                csv_input = csv.reader(stream)
                headers = next(csv_input)  # Skip header row
                
                success_count = 0
                error_count = 0
                
                if import_type == 'students':
                    for row in csv_input:
                        try:
                            if len(row) >= 5:  # name, age, gender, program, contact
                                execute_insert(
                                    'INSERT INTO students (name, age, gender, program, contact) VALUES (?, ?, ?, ?, ?)',
                                    (row[0], int(row[1]) if row[1] else None, row[2], row[3], row[4])
                                )
                                success_count += 1
                        except Exception as e:
                            error_count += 1
                            continue
                
                elif import_type == 'appointments':
                    for row in csv_input:
                        try:
                            if len(row) >= 5:  # student_id, counselor_id, date, time, purpose
                                execute_insert(
                                    'INSERT INTO appointments (student_id, counselor_id, date, time, purpose) VALUES (?, ?, ?, ?, ?)',
                                    (int(row[0]), int(row[1]), row[2], row[3], row[4])
                                )
                                success_count += 1
                        except Exception as e:
                            error_count += 1
                            continue
                
                elif import_type == 'sessions':
                    for row in csv_input:
                        try:
                            if len(row) >= 4:  # appointment_id, counselor_id, session_type, notes
                                execute_insert(
                                    'INSERT INTO sessions (appointment_id, counselor_id, session_type, notes) VALUES (?, ?, ?, ?)',
                                    (int(row[0]) if row[0] else None, int(row[1]), row[2], row[3])
                                )
                                success_count += 1
                        except Exception as e:
                            error_count += 1
                            continue
                
                flash(f'Import completed: {success_count} records added, {error_count} errors', 'success' if error_count == 0 else 'warning')
                
            except Exception as e:
                flash(f'Error processing file: {str(e)}', 'error')
        else:
            flash('Please upload a valid CSV file', 'error')
    
    return render_template('bulk_import.html')

@app.route('/export')
def bulk_export():
    """Bulk export functionality"""
    return render_template('bulk_export.html')

@app.route('/export/<table_name>')
def export_table(table_name):
    """Export specific table to CSV"""
    try:
        # Define table queries
        queries = {
            'students': 'SELECT * FROM students',
            'counselors': 'SELECT * FROM counselors', 
            'appointments': '''SELECT a.*, s.name as student_name, c.name as counselor_name
                             FROM appointments a
                             JOIN students s ON a.student_id = s.id
                             JOIN counselors c ON a.counselor_id = c.id''',
            'sessions': '''SELECT sess.*, st.name as student_name, c.name as counselor_name
                          FROM sessions sess
                          LEFT JOIN appointments a ON sess.appointment_id = a.id
                          LEFT JOIN students st ON a.student_id = st.id
                          JOIN counselors c ON sess.counselor_id = c.id''',
            'case_management': '''SELECT cm.*, st.name as student_name
                                 FROM case_management cm
                                 JOIN sessions s ON cm.session_id = s.id
                                 LEFT JOIN appointments a ON s.appointment_id = a.id
                                 LEFT JOIN students st ON a.student_id = st.id''',
            'referrals': '''SELECT r.*, st.name as student_name
                           FROM referrals r
                           JOIN sessions s ON r.session_id = s.id
                           LEFT JOIN appointments a ON s.appointment_id = a.id
                           LEFT JOIN students st ON a.student_id = st.id''',
            'outcome_questionnaires': '''SELECT oq.*, s.name as student_name
                                        FROM outcome_questionnaires oq
                                        JOIN students s ON oq.student_id = s.id''',
            'dass21': '''SELECT d.*, s.name as student_name
                        FROM dass21 d
                        JOIN students s ON d.student_id = s.id'''
        }
        
        if table_name not in queries:
            flash('Invalid table name', 'error')
            return redirect(url_for('bulk_export'))
        
        # Execute query
        data = execute_query(queries[table_name])
        
        # Create CSV response
        output = io.StringIO()
        writer = csv.writer(output)
        
        if data:
            # Write headers
            writer.writerow(data[0].keys())
            # Write data
            for row in data:
                writer.writerow(row)
        
        # Create response
        response = make_response(output.getvalue())
        response.headers['Content-Type'] = 'text/csv'
        response.headers['Content-Disposition'] = f'attachment; filename={table_name}_{datetime.now().strftime("%Y%m%d")}.csv'
        
        return response
        
    except Exception as e:
        flash(f'Error exporting {table_name}: {str(e)}', 'error')
        return redirect(url_for('bulk_export'))

@app.route('/export/all')
def export_all():
    """Export all tables as a ZIP file"""
    try:
        # Create a temporary zip file in memory
        zip_buffer = io.BytesIO()
        
        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
            tables = ['students', 'counselors', 'appointments', 'sessions', 
                     'case_management', 'referrals', 'outcome_questionnaires', 'dass21']
            
            for table in tables:
                # Get data for each table
                data = execute_query(f'SELECT * FROM {table}')
                
                if data:
                    # Create CSV content
                    csv_content = io.StringIO()
                    writer = csv.writer(csv_content)
                    writer.writerow(data[0].keys())
                    for row in data:
                        writer.writerow(row)
                    
                    # Add to zip
                    zip_file.writestr(f'{table}.csv', csv_content.getvalue())
        
        zip_buffer.seek(0)
        
        # Create response
        response = make_response(zip_buffer.getvalue())
        response.headers['Content-Type'] = 'application/zip'
        response.headers['Content-Disposition'] = f'attachment; filename=counseling_data_{datetime.now().strftime("%Y%m%d")}.zip'
        
        return response
        
    except Exception as e:
        flash(f'Error creating export: {str(e)}', 'error')
        return redirect(url_for('bulk_export'))

@app.route('/report')
def report():
    """Report writer with live data analysis"""
    try:
        # Collect statistics for report
        stats = {}
        
        # Basic counts
        stats['total_students'] = execute_query('SELECT COUNT(*) as count FROM students')[0]['count']
        stats['total_sessions'] = execute_query('SELECT COUNT(*) as count FROM sessions')[0]['count']
        stats['total_referrals'] = execute_query('SELECT COUNT(*) as count FROM referrals')[0]['count']
        
        # Gender distribution
        gender_dist = execute_query('SELECT gender, COUNT(*) as count FROM students GROUP BY gender')
        stats['gender_distribution'] = {row['gender']: row['count'] for row in gender_dist}
        
        # Program distribution
        program_dist = execute_query('SELECT program, COUNT(*) as count FROM students GROUP BY program ORDER BY count DESC LIMIT 5')
        stats['top_programs'] = [(row['program'], row['count']) for row in program_dist]
        
        # Session types
        session_types = execute_query('SELECT session_type, COUNT(*) as count FROM sessions GROUP BY session_type')
        stats['session_types'] = {row['session_type']: row['count'] for row in session_types}
        
        # Average outcome scores
        avg_oq = execute_query('SELECT AVG(total_score) as avg_score FROM outcome_questionnaires')
        stats['avg_outcome_score'] = round(avg_oq[0]['avg_score'], 2) if avg_oq[0]['avg_score'] else 0
        
        # DASS-21 averages
        dass_avg = execute_query('SELECT AVG(depression_score) as dep, AVG(anxiety_score) as anx, AVG(stress_score) as stress FROM dass21')
        if dass_avg and dass_avg[0]['dep']:
            stats['dass_averages'] = {
                'depression': round(dass_avg[0]['dep'], 2),
                'anxiety': round(dass_avg[0]['anx'], 2),
                'stress': round(dass_avg[0]['stress'], 2)
            }
        else:
            stats['dass_averages'] = {'depression': 0, 'anxiety': 0, 'stress': 0}
        
        # Monthly session trends (last 6 months)
        monthly_sessions = execute_query('''
            SELECT strftime('%Y-%m', created_at) as month, COUNT(*) as count 
            FROM sessions 
            WHERE created_at >= date('now', '-6 months')
            GROUP BY strftime('%Y-%m', created_at)
            ORDER BY month
        ''')
        stats['monthly_trends'] = [(row['month'], row['count']) for row in monthly_sessions]
        
        # Common referral reasons
        referral_reasons = execute_query('''
            SELECT reasons, COUNT(*) as count 
            FROM referrals 
            GROUP BY reasons 
            ORDER BY count DESC 
            LIMIT 5
        ''')
        stats['common_referrals'] = [(row['reasons'], row['count']) for row in referral_reasons]
        
        return render_template('report.html', stats=stats)
        
    except Exception as e:
        flash(f'Error generating report: {str(e)}', 'error')
        return render_template('report.html', stats={})

@app.route('/download_report', methods=['POST'])
def download_report():
    """Download report as Word document"""
    try:
        report_text = request.form['report_content']
        report_title = request.form.get('report_title', 'Counseling Center Report')
        
        # Create Word document
        doc = Document()
        
        # Add title
        title = doc.add_heading(report_title, 0)
        
        # Add date
        doc.add_paragraph(f'Generated on: {datetime.now().strftime("%B %d, %Y")}')
        doc.add_paragraph('')
        
        # Add report content
        for paragraph in report_text.split('\n\n'):
            if paragraph.strip():
                doc.add_paragraph(paragraph.strip())
        
        # Save to memory
        doc_buffer = io.BytesIO()
        doc.save(doc_buffer)
        doc_buffer.seek(0)
        
        # Create response
        response = make_response(doc_buffer.getvalue())
        response.headers['Content-Type'] = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        response.headers['Content-Disposition'] = f'attachment; filename=counseling_report_{datetime.now().strftime("%Y%m%d")}.docx'
        
        return response
        
    except Exception as e:
        flash(f'Error creating report download: {str(e)}', 'error')
        return redirect(url_for('report'))

@app.route('/print/<record_type>/<int:record_id>')
def print_record(record_type, record_id):
    """Print-friendly PDF generation for records"""
    try:
        if record_type == 'student':
            student = execute_query('SELECT * FROM students WHERE id = ?', (record_id,))
            if not student:
                flash('Student not found', 'error')
                return redirect(url_for('students_list'))
            return render_template('print_student.html', student=student[0])
        
        elif record_type == 'appointment':
            appointment = execute_query('''
                SELECT a.*, s.name as student_name, c.name as counselor_name
                FROM appointments a
                JOIN students s ON a.student_id = s.id
                JOIN counselors c ON a.counselor_id = c.id
                WHERE a.id = ?
            ''', (record_id,))
            if not appointment:
                flash('Appointment not found', 'error')
                return redirect(url_for('appointments_list'))
            return render_template('print_appointment.html', appointment=appointment[0])
        
        elif record_type == 'session':
            session = execute_query('''
                SELECT s.*, st.name as student_name, c.name as counselor_name,
                       a.date as appointment_date, a.time as appointment_time
                FROM sessions s
                LEFT JOIN appointments a ON s.appointment_id = a.id
                LEFT JOIN students st ON a.student_id = st.id
                JOIN counselors c ON s.counselor_id = c.id
                WHERE s.id = ?
            ''', (record_id,))
            if not session:
                flash('Session not found', 'error')
                return redirect(url_for('sessions_list'))
            return render_template('print_session.html', session=session[0])
        
        else:
            flash('Invalid record type', 'error')
            return redirect(url_for('dashboard'))
            
    except Exception as e:
        flash(f'Error generating print view: {str(e)}', 'error')
        return redirect(url_for('dashboard'))

# Template download routes for CSV import
@app.route('/download_template/<template_type>')
def download_template(template_type):
    """Download CSV templates for bulk import"""
    templates = {
        'students': [['name', 'age', 'gender', 'program', 'contact'],
                    ['John Doe', '20', 'Male', 'Computer Science', 'john@example.com']],
        'appointments': [['student_id', 'counselor_id', 'date', 'time', 'purpose'],
                        ['1', '1', '2025-07-30', '10:00', 'Initial consultation']],
        'sessions': [['appointment_id', 'counselor_id', 'session_type', 'notes'],
                    ['1', '1', 'Individual', 'First session notes']]
    }
    
    if template_type not in templates:
        flash('Invalid template type', 'error')
        return redirect(url_for('bulk_import'))
    
    # Create CSV
    output = io.StringIO()
    writer = csv.writer(output)
    for row in templates[template_type]:
        writer.writerow(row)
    
    response = make_response(output.getvalue())
    response.headers['Content-Type'] = 'text/csv'
    response.headers['Content-Disposition'] = f'attachment; filename={template_type}_template.csv'
    
    return response
